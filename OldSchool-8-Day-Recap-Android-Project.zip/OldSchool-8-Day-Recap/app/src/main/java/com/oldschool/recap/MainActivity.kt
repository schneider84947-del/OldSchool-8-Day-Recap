package com.oldschool.recap

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("recap", MODE_PRIVATE) }
    private val rows = mutableListOf<Pair<String, Double>>()
    private lateinit var list: LinearLayout
    private lateinit var total: TextView
    private lateinit var remaining: TextView
    private lateinit var dateInput: EditText
    private lateinit var hoursInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.rgb(17, 24, 39))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("OLDSCHOOL 8-DAY RECAP", 26, Color.WHITE, true))
        page.addView(label("Track on-duty hours. 70-hour / 8-day cycle.", 15, Color.LTGRAY))
        total = label("", 20, Color.WHITE, true); page.addView(total)
        remaining = label("", 18, Color.rgb(74, 222, 128), true); page.addView(remaining)

        dateInput = EditText(this).apply {
            hint = "Date (MM/dd/yyyy)"
            setText(SimpleDateFormat("MM/dd/yyyy", Locale.US).format(Date()))
            setSingleLine()
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        hoursInput = EditText(this).apply {
            hint = "On-duty hours (e.g. 8.5)"
            inputType = 8194
            setSingleLine()
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        page.addView(dateInput, params()); page.addView(hoursInput, params())
        val add = Button(this).apply { text = "ADD / UPDATE DAY"; setOnClickListener { addDay() } }
        page.addView(add, params())
        val export = Button(this).apply { text = "EXPORT BACKUP"; setOnClickListener { exportBackup() } }
        page.addView(export, params())
        val import = Button(this).apply { text = "IMPORT BACKUP"; setOnClickListener { importBackup() } }
        page.addView(import, params())
        page.addView(label("DAILY ENTRIES", 18, Color.WHITE, true))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(list)
        refresh()
    }

    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if (bold) setTypeface(null, 1); setPadding(0, 12, 0, 12) }
    private fun params() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin=8 }

    private fun addDay() {
        val date = dateInput.text.toString().trim()
        val hours = hoursInput.text.toString().toDoubleOrNull()
        val parsed = runCatching { SimpleDateFormat("MM/dd/yyyy", Locale.US).apply { isLenient=false }.parse(date) }.getOrNull()
        if (parsed == null || hours == null || hours < 0 || hours > 24) {
            Toast.makeText(this, "Enter a valid date and hours from 0 to 24.", Toast.LENGTH_LONG).show(); return
        }
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(parsed)
        rows.removeAll { it.first == key }
        rows.add(key to hours)
        rows.sortBy { it.first }
        save(); refresh()
        Toast.makeText(this, "Day saved.", Toast.LENGTH_SHORT).show()
    }

    private fun rolling(): List<Pair<String, Double>> {
        val cal = Calendar.getInstance()
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        val cutoff = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -7) }
        val min = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cutoff.time)
        return rows.filter { it.first >= min && it.first <= today }
    }

    private fun refresh() {
        val sum = rolling().sumOf { it.second }
        total.text = "8-DAY TOTAL: %.2f / 70.00 hours".format(Locale.US, sum)
        remaining.text = "REMAINING: %.2f hours".format(Locale.US, (70.0-sum).coerceAtLeast(0.0))
        list.removeAllViews()
        rows.sortedByDescending { it.first }.forEach { (d,h) ->
            val line = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            line.addView(label("$d     %.2f hrs".format(Locale.US,h), 16, Color.WHITE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            line.addView(Button(this).apply { text="DELETE"; setOnClickListener { rows.removeAll { it.first==d }; save(); refresh() } })
            list.addView(line)
        }
    }

    private fun save() {
        val a = JSONArray()
        rows.forEach { (d,h) -> a.put(JSONObject().put("date",d).put("hours",h)) }
        prefs.edit().putString("entries", a.toString()).apply()
    }
    private fun load() {
        runCatching {
            val a = JSONArray(prefs.getString("entries","[]"))
            for (i in 0 until a.length()) { val o=a.getJSONObject(i); rows.add(o.getString("date") to o.getDouble("hours")) }
        }
    }
    private fun exportBackup() {
        val i = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE); type="application/json"; putExtra(android.content.Intent.EXTRA_TITLE,"oldschool-recap-backup.json")
        }
        startActivityForResult(i, 10)
    }
    private fun importBackup() {
        val i = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE); type="application/json"
        }
        startActivityForResult(i, 11)
    }
    @Deprecated("legacy result callback")
    override fun onActivityResult(requestCode:Int, resultCode:Int, data:android.content.Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (resultCode != RESULT_OK || data?.data == null) return
        runCatching {
            if (requestCode==10) contentResolver.openOutputStream(data.data!!)!!.use { it.write(prefs.getString("entries","[]")!!.toByteArray()) }
            if (requestCode==11) {
                val raw=contentResolver.openInputStream(data.data!!)!!.bufferedReader().readText()
                val a=JSONArray(raw); rows.clear()
                for (n in 0 until a.length()) { val o=a.getJSONObject(n); rows.add(o.getString("date") to o.getDouble("hours")) }
                save(); refresh()
            }
        }.onFailure { Toast.makeText(this, "Backup operation failed.", Toast.LENGTH_LONG).show() }
    }
}
